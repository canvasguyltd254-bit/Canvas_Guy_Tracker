/* The Seating Company — small, delegated, section-editor-safe interactions. */
(function () {
  'use strict';

  var requestController = null;

  function announce(message, target) {
    if (target) target.textContent = message;
    var toast = document.getElementById('toast');
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    window.clearTimeout(announce.timer);
    announce.timer = window.setTimeout(function () { toast.classList.remove('show'); }, 3200);
  }

  function money(cents) {
    var currency = document.body.dataset.currency || 'KES';
    var locale = document.body.dataset.locale || 'en-KE';
    try {
      return new Intl.NumberFormat(locale, { style: 'currency', currency: currency }).format(cents / 100);
    } catch (error) {
      return currency + ' ' + (cents / 100).toFixed(2);
    }
  }

  function setLoading(button, loading) {
    if (!button) return;
    button.classList.toggle('is-loading', loading);
    button.setAttribute('aria-busy', loading ? 'true' : 'false');
    button.disabled = loading || button.dataset.unavailable === 'true';
  }

  async function addItems(items, signal) {
    var rootPath = window.Shopify && window.Shopify.routes ? window.Shopify.routes.root : '/';
    var response = await fetch(rootPath + 'cart/add.js', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ items: items }),
      signal: signal
    });
    var data = await response.json();
    if (!response.ok) throw new Error(data.description || 'Could not add this item');
    return data;
  }

  async function refreshCartCount() {
    try {
      var rootPath = window.Shopify && window.Shopify.routes ? window.Shopify.routes.root : '/';
      var response = await fetch(rootPath + 'cart.js', { headers: { Accept: 'application/json' } });
      if (!response.ok) return;
      var cart = await response.json();
      document.querySelectorAll('[data-cart-count]').forEach(function (element) {
        element.textContent = cart.item_count;
        element.dataset.cartCount = cart.item_count;
      });
    } catch (error) {
      /* The cart page remains available if a background count refresh fails. */
    }
  }

  function productData(root) {
    if (root._variants) return root._variants;
    var script = root.querySelector('[data-product-variants]');
    try { root._variants = JSON.parse(script.textContent); } catch (error) { root._variants = []; }
    return root._variants;
  }

  function selectedOptions(root) {
    return Array.from(root.querySelectorAll('[data-option-position]')).map(function (group) {
      var selected = group.querySelector('[data-option-value].is-selected');
      return selected ? selected.dataset.optionValue : '';
    });
  }

  function updateProduct(root) {
    var options = selectedOptions(root);
    var variant = productData(root).find(function (item) {
      return item.options.every(function (value, index) { return value === options[index]; });
    });
    var input = root.querySelector('[data-variant-id]');
    var submit = root.querySelector('[data-add-to-cart]');
    var label = root.querySelector('[data-add-label]');
    var availability = root.querySelector('[data-product-availability]');
    var price = root.querySelector('[data-product-price]');
    var compare = root.querySelector('[data-product-compare]');

    if (!variant) {
      input.value = '';
      submit.dataset.unavailable = 'true';
      submit.disabled = true;
      label.textContent = 'Unavailable';
      availability.textContent = 'This combination is unavailable';
      return;
    }

    input.value = variant.id;
    submit.dataset.unavailable = variant.available ? 'false' : 'true';
    submit.disabled = !variant.available;
    label.textContent = variant.available ? 'Add to cart' : 'Sold out';
    availability.textContent = variant.available ? 'In stock' : 'Currently unavailable';
    price.textContent = money(variant.price);
    if (variant.compare_at_price && variant.compare_at_price > variant.price) {
      compare.textContent = money(variant.compare_at_price);
      compare.classList.remove('is-hidden');
    } else {
      compare.textContent = '';
      compare.classList.add('is-hidden');
    }

    var bundleButton = document.querySelector('[data-bundle-add]');
    if (bundleButton) bundleButton.dataset.mainVariant = variant.id;
    if (variant.featured_image && variant.featured_image.src) {
      var image = root.querySelector('.product-main-image');
      if (image) {
        image.src = variant.featured_image.src;
        image.srcset = '';
        image.alt = variant.featured_image.alt || image.alt;
      }
    }
    if (window.history && root.dataset.productUrl) {
      window.history.replaceState({}, '', root.dataset.productUrl + '?variant=' + variant.id);
    }
  }

  document.addEventListener('click', function (event) {
    var projectFilter = event.target.closest('[data-project-filters] [data-filter]');
    if (projectFilter) {
      var filterBar = projectFilter.closest('[data-project-filters]');
      filterBar.querySelectorAll('[data-filter]').forEach(function (button) {
        var selected = button === projectFilter;
        button.classList.toggle('is-active', selected);
        button.setAttribute('aria-pressed', selected ? 'true' : 'false');
        button.style.background = selected ? 'var(--gold)' : '#fff';
        button.style.color = selected ? '#fff' : 'var(--mid)';
        button.style.border = selected ? '0' : '1px solid var(--border)';
      });
      document.querySelectorAll('.proj').forEach(function (card) {
        card.hidden = projectFilter.dataset.filter !== 'all' && card.dataset.category !== projectFilter.dataset.filter;
      });
      return;
    }

    var quantityButton = event.target.closest('[data-qty-minus], [data-qty-plus]');
    if (quantityButton) {
      var picker = quantityButton.closest('.quantity-picker');
      var quantityInput = picker && picker.querySelector('[data-qty-input]');
      if (quantityInput) {
        var value = parseInt(quantityInput.value, 10) || 1;
        quantityInput.value = quantityButton.hasAttribute('data-qty-minus') ? Math.max(1, value - 1) : value + 1;
        quantityInput.dispatchEvent(new Event('change', { bubbles: true }));
      }
      return;
    }

    var optionButton = event.target.closest('[data-option-value]');
    if (optionButton) {
      var group = optionButton.closest('[data-option-position]');
      group.querySelectorAll('[data-option-value]').forEach(function (button) {
        var selected = button === optionButton;
        button.classList.toggle('is-selected', selected);
        button.setAttribute('aria-pressed', selected ? 'true' : 'false');
      });
      group.querySelector('[data-selected-option]').textContent = optionButton.dataset.optionValue;
      updateProduct(optionButton.closest('[data-product-root]'));
      return;
    }

    var thumbnail = event.target.closest('[data-product-thumbnail]');
    if (thumbnail) {
      var gallery = thumbnail.closest('.product-gallery');
      var mainImage = gallery.querySelector('.product-main-image');
      gallery.querySelectorAll('[data-product-thumbnail]').forEach(function (button) {
        var active = button === thumbnail;
        button.classList.toggle('is-active', active);
        button.setAttribute('aria-pressed', active ? 'true' : 'false');
      });
      if (mainImage) {
        mainImage.src = thumbnail.dataset.imageSrc;
        mainImage.srcset = thumbnail.dataset.imageSrcset;
        mainImage.alt = thumbnail.dataset.imageAlt;
      }
      return;
    }

    var bundleButton = event.target.closest('[data-bundle-add]');
    if (bundleButton) {
      var bundleRoot = bundleButton.closest('[data-bundle-root]');
      var bundleMessage = bundleRoot.querySelector('[data-bundle-message]');
      setLoading(bundleButton, true);
      addItems([
        { id: Number(bundleButton.dataset.mainVariant), quantity: 1 },
        { id: Number(bundleButton.dataset.addonVariant), quantity: 1 }
      ]).then(function () {
        announce('Both items were added to your cart.', bundleMessage);
        refreshCartCount();
      }).catch(function (error) {
        announce(error.message, bundleMessage);
      }).finally(function () { setLoading(bundleButton, false); });
    }
  });

  document.addEventListener('submit', function (event) {
    var form = event.target.closest('[data-product-form]');
    if (!form) return;
    event.preventDefault();
    var submit = form.querySelector('[data-add-to-cart]');
    var message = form.querySelector('[data-product-message]');
    var id = Number(form.querySelector('[data-variant-id]').value);
    var quantity = Number(form.querySelector('[data-qty-input]').value) || 1;
    if (!id) return announce('Choose an available combination.', message);

    if (requestController) requestController.abort();
    requestController = new AbortController();
    setLoading(submit, true);
    addItems([{ id: id, quantity: quantity }], requestController.signal).then(function () {
      announce('Added to your cart.', message);
      refreshCartCount();
    }).catch(function (error) {
      if (error.name !== 'AbortError') announce(error.message, message);
    }).finally(function () {
      setLoading(submit, false);
      requestController = null;
    });
  });

  document.addEventListener('DOMContentLoaded', function () {
    var success = document.querySelector('[data-form-success]');
    if (success) announce(success.dataset.formSuccess || 'Thanks — your message was received.');
  });

  // Scroll-reveal: progressive enhancement only. Elements stay visible by
  // default (no .reveal class in markup); this adds it at runtime, so a
  // blocked/failed script never hides content. Skips anything already
  // above the fold at load so nothing flashes invisible on first paint.
  function initScrollReveal() {
    if (!('IntersectionObserver' in window)) return;
    var targets = document.querySelectorAll(
      '.card, .stat, .feature, .proj, .step, .wf-h2, .sec-tag, .newsletter'
    );
    if (!targets.length) return;

    var viewportH = window.innerHeight || document.documentElement.clientHeight;
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          var el = entry.target;
          el.classList.add('is-visible');
          observer.unobserve(el);
          // Drop .reveal/.is-visible once the transition finishes so the
          // element goes back to being governed only by its own component
          // rules (.card:hover etc.) — otherwise .reveal.is-visible{transform:none}
          // permanently outranks .card:hover{transform:translateY(-6px)} at
          // equal specificity, silently killing the hover lift forever.
          el.addEventListener('transitionend', function cleanup(event) {
            if (event.target !== el || event.propertyName !== 'transform') return;
            el.classList.remove('reveal', 'is-visible');
            el.removeEventListener('transitionend', cleanup);
          });
        }
      });
    }, { rootMargin: '0px 0px -10% 0px', threshold: 0.1 });

    targets.forEach(function (el) {
      if (el.getBoundingClientRect().top < viewportH) return; // already visible, don't hide it
      el.classList.add('reveal');
      observer.observe(el);
    });
  }

  // Hero background video: apply the merchant's slow-motion speed, and leave the
  // poster frame in place entirely for visitors who ask for reduced motion.
  function initHeroVideo() {
    var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    document.querySelectorAll('[data-hero-media]').forEach(function (wrap) {
      var video = wrap.querySelector('video');
      if (!video) return;

      if (reduced) {
        video.removeAttribute('autoplay');
        video.pause();
        return;
      }

      var speed = parseInt(wrap.dataset.speed, 10);
      if (!isNaN(speed) && speed > 0) video.playbackRate = speed / 100;

      // Some browsers reset playbackRate once metadata loads.
      video.addEventListener('loadedmetadata', function () {
        if (!isNaN(speed) && speed > 0) video.playbackRate = speed / 100;
      });

      // Autoplay can still be refused (low-power mode); poster then remains.
      var attempt = video.play();
      if (attempt && typeof attempt.catch === 'function') attempt.catch(function () {});
    });
  }

  // Cross-sell product rail. The rail scrolls natively (swipe / trackpad /
  // keyboard), so this only adds arrow buttons and optional auto-advance —
  // if the script never runs the rail is still fully usable.
  function initCrossSellRail() {
    document.querySelectorAll('[data-cs-rail]').forEach(function (rail) {
      var section = rail.closest('.cross-sell');
      if (!section) return;

      var prev = section.querySelector('[data-cs-prev]');
      var next = section.querySelector('[data-cs-next]');
      var card = rail.querySelector('.cs-card');
      if (!card) return;

      function step() {
        var gap = parseFloat(getComputedStyle(rail).columnGap || getComputedStyle(rail).gap) || 16;
        return card.getBoundingClientRect().width + gap;
      }
      function maxScroll() {
        return rail.scrollWidth - rail.clientWidth;
      }
      function syncArrows() {
        if (!prev || !next) return;
        var x = rail.scrollLeft;
        prev.disabled = x < 4;
        next.disabled = x > maxScroll() - 4;
      }

      if (prev) prev.addEventListener('click', function () { rail.scrollBy({ left: -step(), behavior: 'smooth' }); });
      if (next) next.addEventListener('click', function () { rail.scrollBy({ left: step(), behavior: 'smooth' }); });

      rail.addEventListener('scroll', syncArrows, { passive: true });
      window.addEventListener('resize', syncArrows);
      syncArrows();

      // Auto-advance is opt-in, and never runs against a reduced-motion preference.
      var seconds = parseInt(rail.dataset.autoplay, 10);
      var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      if (!seconds || reduced) return;

      var timer = null;
      function advance() {
        if (rail.scrollLeft > maxScroll() - 4) {
          rail.scrollTo({ left: 0, behavior: 'smooth' });
        } else {
          rail.scrollBy({ left: step(), behavior: 'smooth' });
        }
      }
      function start() { if (!timer) timer = window.setInterval(advance, seconds * 1000); }
      function stop() { window.clearInterval(timer); timer = null; }

      section.addEventListener('mouseenter', stop);
      section.addEventListener('mouseleave', start);
      section.addEventListener('focusin', stop);
      section.addEventListener('focusout', start);
      document.addEventListener('visibilitychange', function () {
        if (document.hidden) { stop(); } else { start(); }
      });

      start();
    });
  }

  function initTheme() {
    initScrollReveal();
    initHeroVideo();
    initCrossSellRail();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initTheme);
  } else {
    initTheme();
  }
})();


/* The Seating Company — remembers where a visitor came from (UTM tags, landing page, outside referrer)
   for 30 days, so the enquiry form can pass it to the CRM. Kept only in this browser; nothing is
   sent anywhere until the visitor submits the enquiry form and agrees to be contacted. */
(function () {
  'use strict';
  try {
    var KEY = 'tsc_attribution', TTL = 30 * 24 * 60 * 60 * 1000;
    var UTM = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content'];
    var params = new URLSearchParams(window.location.search);
    var cur = { t: Date.now() }, tagged = false;
    UTM.forEach(function (k) { var v = params.get(k); if (v) { cur[k] = v.slice(0, 100); tagged = true; } });
    var saved = null;
    try { saved = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) { saved = null; }
    var fresh = saved && saved.t && (Date.now() - saved.t) < TTL;
    if (fresh && !tagged) return;                         /* keep the earlier visit unless a new campaign link was used */
    cur.landing_page = window.location.origin + window.location.pathname;
    var ref = document.referrer || '';
    if (ref && ref.indexOf(window.location.host) === -1) cur.referrer = ref.slice(0, 500);
    localStorage.setItem(KEY, JSON.stringify(cur));
  } catch (e) { /* private mode or blocked storage: skip silently */ }
})();
